//
//  SettingsVC.swift
//  Hangman
//
//  Created by Shiva Medapati on 11/29/22.
//

import UIKit

class SettingsVC: UIViewController {
var colour = " "
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
   
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            let vc = segue.destination as! AboutVC
            
            vc.view.backgroundColor = self.view.backgroundColor
            vc.abouttext.backgroundColor = self.view.backgroundColor
            
            
        }
    
    @IBAction func bluebtnactn(_ sender: Any) {
        self.view.backgroundColor = UIColor(red: 0.68, green: 0.85, blue: 0.90, alpha: 1.00)
        
    }
    
    @IBAction func greenbtnactn(_ sender: Any) {
        self.view.backgroundColor = UIColor(red: 0.56, green: 0.93, blue: 0.56, alpha: 1.00)
    }
    
    @IBAction func aboutbtnactn(_ sender: Any) {
       
        performSegue(withIdentifier: "settings2about", sender: self)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
