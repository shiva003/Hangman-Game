//
//  DoublePlayerVC.swift
//  Hangman
//
//  Created by Shiva Medapati on 9/14/22.
//

import UIKit

class DoublePlayerVC: UIViewController {
    @IBOutlet weak var tfGuessWord: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        tfGuessWord.becomeFirstResponder()

    }
    
  //  @IBAction func btnActionMenu(_ sender: Any) {
  //      dismiss(animated: true, completion: nil)
  //  }
    
    @IBAction func btnActionPlay(_ sender: Any) {
        performSegue(withIdentifier: "doubleplayer2game", sender: self)
        self.view.backgroundColor = UIColor.white
    }
    
    @IBAction func historybtnactn(_ sender: Any) {
        performSegue(withIdentifier: "double2history", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "doubleplayer2game" {
                if let gameVC = segue.destination as? GameVC {
                    if let enteredText = tfGuessWord.text {
                        gameVC.guessWord = enteredText
                    }
                }
            }
        }

    
   
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
