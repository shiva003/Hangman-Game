//
//  historyTableViewCell.swift
//  Hangman
//
//  Created by Shiva Medapati on 11/28/22.
//

import UIKit

class historyTableViewCell: UITableViewCell {
    @IBOutlet weak var scoreLbl: UILabel!
    
    @IBOutlet weak var Datelbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
