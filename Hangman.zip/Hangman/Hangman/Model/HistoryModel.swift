//
//  HistoryModel.swift
//  Hangman
//
//  Created by Shiva Medapati on 11/28/22.
//

import UIKit

class HistoryModel: NSObject {
    var score:Int32
    var date:Date
    init(score: Int32, date: Date) {
        self.score = score
        self.date = date
    }
}
