//
//  HistoryCRUD.swift
//  Hangman
//
//  Created by Shiva Medapati on 11/28/22.
//

import UIKit
import CoreData

class HistoryCRUD: NSObject {
    static func create(historydata:HistoryModel) {
            //Get the managed context context from AppDelegate
            if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
                let managedContext = appDelegate.persistentContainer.viewContext
                //Create a new empty record.
                let HistoryEntity = NSEntityDescription.entity(forEntityName: "History", in: managedContext)!
                //Fill the new record with values
                let historyentry = NSManagedObject(entity: HistoryEntity, insertInto: managedContext)
                historyentry.setValue(historydata.score, forKeyPath: "score")
                historyentry.setValue(historydata.date, forKey: "date")
                do {
                    //Save the managed object context
                    try managedContext.save()
                } catch let error as NSError {
                    print("Could not create the new record! \(error), \(error.userInfo)")
                }
            }
        }
    static func read() -> [HistoryModel]? {
            //Get the managed context context from AppDelegate
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            let managedContext = appDelegate.persistentContainer.viewContext
            
            //Prepare the request of type NSFetchRequest  for the entity (SELECT * FROM)
            let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "History")
            //Add a contition to the fetch request (WHERE)
            //fetchRequest.predicate = NSPredicate(format: "date = %@", date)
            //Add a sorting preference (ORDER BY)
           // fetchRequest.sortDescriptors = [NSSortDescriptor.init(key: "word", ascending: false)]
            
            do {
                            //Execute the fetch request
                            let result = try managedContext.fetch(fetchRequest)
                if result.count >= 0 {
                    var dataarr = [HistoryModel]()
                    for i in 0 ..< result.count{
                        let record = result[i] as! NSManagedObject
                        let score = record.value(forKey: "score") as! Int32
                        let date = record.value(forKey: "date") as! Date
                        let HistoryModel = HistoryModel(score: score, date: date)
                        dataarr.append(HistoryModel)
                    }
                    return dataarr
                    }
                        } catch let error as NSError {
                            print("Could not fetch the record! \(error), \(error.userInfo)")
                        }
                    }
                    return nil
                }
}
